#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int longestPalindromicSubsequence(const string& s, int left, int right) {
    if (left > right) {
        return 0;
    }
    if (left == right) {
        return 1;
    }
    if (s[left] == s[right]) {
        return 2 + longestPalindromicSubsequence(s, left + 1, right - 1);
    }

    return max(longestPalindromicSubsequence(s, left + 1, right),
                    longestPalindromicSubsequence(s, left, right - 1));
}

int main() {
    string s;
    cout<<"str : ";
    getline(cin,s);

    int n = s.length();
    int maxLength = longestPalindromicSubsequence(s, 0, n - 1);
    cout<<"longest palindromic subsequence has the length : ";
    cout << maxLength << endl;

    return 0;
}
