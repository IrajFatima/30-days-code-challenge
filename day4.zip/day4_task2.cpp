#include <iostream>
using namespace std;
int main(){
    int f=1,n;
    cout<<"Number : ";
    cin>>n;
    for(int i=1;i<=n;i++)
        f*=i;
    cout<<"factorial : "<<f;       
}