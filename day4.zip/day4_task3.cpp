#include <iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"Enter number 1 : ";
    cin>>a;
    cout<<"Enter number 2 : ";
    cin>>b;
    a=a^b;
    b=a^b;
    a=a^b;
    cout<<"Number 1 : "<<a<<endl;
    cout<<"Number 2 : "<<b;
}