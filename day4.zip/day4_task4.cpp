#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main(){
    srand(time(0));
    int ran=rand()%10+10;
    int n,i=0;
    while(true){
        i++;
        cout<<"Guess the number : ";
        cin>>n;
        if(n==ran){
            cout<<"Bravo! You guessed the number in "<<i<<" tries.";
            break;
        }
        else if(n<10)
            cout<<"Too low! Try Again."<<endl;
        else if(n>20)
            cout<<"Too high! Try Again."<<endl;
        else
            cout<<"You were near! Try again"<<endl;    
    }
    return 0;
}