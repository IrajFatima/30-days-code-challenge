#include <iostream>
using namespace std;

int hcf(int a, int b){
    while(b!=0){
        int temp=b;
        b=a%b;
        a=temp;
    }
    return a;
}

int lcm(int a, int b) {
    int max=(a>b)? a:b;
    while(true){
        if(max%a==0 && max%b==0){
            return max;
        }
        ++max;
    }
}


int main(){
    int a,b;
    cout<<"Number 1: ";
    cin>>a;
    cout<<"Number 2: ";
    cin>>b;
    cout<<"HCF of "<<a<<" and "<<b<<" : "<<hcf(a,b)<<endl;
    cout<<"LCM of "<<a<<" and "<<b<<" : "<<lcm(a,b)<<endl;
}