#include <iostream>
using namespace std;

void swap(int& a,int& b){
    a+=b;
    b=a-b;
    a-=b;
}
int main(){
    int a,b;
    cout<<"Number 1: ";
    cin>>a;
    cout<<"Number 2: ";
    cin>>b;
    swap(a,b);
    cout<<"after swapping"<<endl;
    cout<<"Number 1: "<<a<<endl;
    cout<<"Number 2: "<<b<<endl;
}