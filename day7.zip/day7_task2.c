#include <stdio.h>
int main(){
    int a;
    int*ptr;
    printf("Enter the number : ");
    scanf("%d",&a);
    ptr=&a;

    printf("%d is stored in memory location %p(16), %o(8) and %d(10) of my system.\n", a, ptr, ptr, ptr);
}