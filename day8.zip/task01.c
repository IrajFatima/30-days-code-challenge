#include<stdio.h>
int main(){
    int size;
    printf("Enter the number of values:");
    scanf("%d", &size);
    int arr[size];
    int sum = 0;
    float ave;
    printf("Enter %d Numbers : ",size);
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &arr[i]);
       
    
    }
    for (int i = 0; i < size; i++)
    {
        sum += arr[i];
    }
    
    ave = sum / size;
    printf("Sum :%d\n ", sum);
    printf("Average :%.2f\n ", ave);
}