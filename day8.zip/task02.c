#include <stdio.h>
int main()
{
    int size;
    printf("Enter the number of values:");
    scanf("%d", &size);
    int arr[size];
    int max = 0;
    int min = 999;
    printf("Enter %d Numbers : ", size);
    for (int i = 0; i < size ; i++)
    {
        scanf("%d", &arr[i]);
        if (arr[i] > max)
            max = arr[i];
        if (arr[i] < min)
            min = arr[i];
    }

    printf("Maximum Number :%d\n ",max);
    printf("Minimum Number :%d\n ",min);
}