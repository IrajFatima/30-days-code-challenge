#include <iostream>
using namespace std;

typedef struct rectangle{
    int length;
    int width;
} rect;


int main(){
    rect r;
    cout<<"Enter dimensions of rectangle : ";
    cin>>r.length>>r.width;
    cout<<"Area of rectangle : "<<r.length*r.width;
}
