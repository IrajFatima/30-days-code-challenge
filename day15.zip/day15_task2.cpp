#include <iostream>
using namespace std;
#include <string>
#include <new>
union var
{
    int int_val;
    float float_val;
    string char_val;

    var(){}
    ~var(){}
};

int main(){
    int choice;
    var var1;
    cout<<"Enter the choice(1 for integer, 2 for float,3 for strings ): ";
    cin>>choice;
    switch(choice){
        case 1:
            cout<<"Enter the integer value: ";
            cin>>var1.int_val;
            cout<<"The integer value is: "<<var1.int_val<<endl;
            break;
        case 2:
            cout<<"Enter the float value: ";
            cin>>var1.float_val;
            cout<<"The float value is: "<<var1.float_val<<endl;
            break;
        case 3:
            new(&var1.char_val) string;
            cout<<"Enter the string value: ";
            cin.ignore();
            cin>>var1.char_val;
            cout<<"The string value is: "<<var1.char_val<<endl;
            var1.char_val.~string();
            break;
    }
}
