#include <iostream>
using namespace std;
#include <cstdlib>



int string_to_int(char* s){
    int number=0;
    for(int i=0;s[i]!=0;i++)
        if(s[i]<='9' && s[i]>='0')
            number= (number*10) + (s[i]-'0');
    return number;
}

int main(){
    string num;
    cout<<"enter string : ";
    cin>>num;
    cout<<string_to_int(&num[0]);
}