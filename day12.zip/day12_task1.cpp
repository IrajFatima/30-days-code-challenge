#include <iostream>
using namespace std;
int main(){
    char arr[256];
    for(int i=0;i<255;i++){
        arr[i]=i+1;
    }
    arr[255]='\0';
    int i;
    cout<<"Decimal\t\tAscii character"<<endl;
    for(i=0;i<255;i++){
        cout<<i<<"\t\t\t"<<arr[i]<<endl<<endl;
    }
}