#include <iostream>
#include <algorithm>
using namespace std;
int main(){
    int size,num,i,count=0;
    cout<<"Enter the number you want to search on list : ";
    cin>>num;
    cout<<"enter number of values : ";
    cin>>size;
    int arr[size];
    cout<<"enter "<<size<<" numbers : ";
    for( i=0;i<size;i++){
        cin>>arr[i];
    }
    for( i=0;i<size;i++)
        if(arr[i]==num){
            cout<<"location of first "<<num<<" in the list : "<<i+1<<endl;
            break;
        }
    if(i==size){
        cout<<"location of first "<<num<<" in the list : "<<-1<<endl;
        cout<<"Number of "<<num<<" in the list : "<<count<<endl;
    }
    else{
        for( i=0;i<size;i++)
            if(arr[i]==num)
                count++;
        cout<<"Number of "<<num<<" in the list : "<<count<<endl;
                
    }


        

}    