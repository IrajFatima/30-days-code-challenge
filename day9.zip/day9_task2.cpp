#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
int main(){
    int size;
    cout<<"enter number of values : ";
    cin>>size;
    int arr[size];
    cout<<"enter "<<size<<" numbers : ";
    for(int i=0;i<size;i++){
        cin>>arr[i];
    }
    sort(arr,arr+size ,greater<int>());
    cout<<"Sorted numbers in descending number : ";
    for(int i=0;i<size;i++){
        cout<<arr[i]<<" ";
    }

}