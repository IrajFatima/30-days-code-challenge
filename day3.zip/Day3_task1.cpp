#include <iostream>
using namespace std;
int main(){
    int a,b,c;
    cout<<"Enter three numbers : ";
    cin>>a>>b>>c;
    int max=a,min=a;
    if(max<b)
        max=b;
    if(max<c)
        max=c;
    if(min>b)
        min=b;
    if(min>c)
        min=c;
    cout<<"Smallest number : "<<min<<endl<<"Greatest number : "<<max;    
}