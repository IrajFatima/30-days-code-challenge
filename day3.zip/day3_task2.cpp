#include <iostream>
using namespace std;
int main(){
    int a,b,c;
    cout<<"Enter three angles of a triangles : ";
    cin>>a>>b>>c;
    if(a+b+c==180)
        cout<<"Yes, such triangle is possible";
    else 
        cout<<"Sorry, such triangle doesn't exist";    
}