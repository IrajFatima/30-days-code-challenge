#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;
int main(){
    int units;
    double cost=0,gst=0,bill=0;
    char ch;
    cout<<"Select the consumer type:\nC for commercial\nH for home\nEnter consumer type: ";
    cin>>ch;
    cout<<"Enter number of units consumed : ";
    cin>>units;
    if(ch=='H'){
        if (units<=100)
            cost+=units*11.0;
        else if(units<=200)
            cost+=(100*11.0)+((units-100)*15.0);
        else
            cost+=(100*11.0)+(100*15.0)+((units-200)*20.0); 
        gst=cost*0.10;
        bill=gst+cost+700;       
    }
    if(ch=='C'){
        if (units<=100)
            cost+=units*15;
        else if(units<=200)
            cost+=(100*15)+((units-100)*22);
        else
            cost+=(100*15)+(100*22)+((units-200)*30.0); 
        gst=cost*0.15;
        bill=gst+cost+1100;       
    }
    cout<<"Electricity Cost: "<<fixed<<setprecision(2)<<cost<<" rupees"<<endl;
    cout<<"GST             : "<<fixed<<setprecision(2)<<gst<<" rupees"<<endl;
    cout<<"Net electricity bill: "<<fixed<<setprecision(2)<<bill<<" rupees"<<endl;
}