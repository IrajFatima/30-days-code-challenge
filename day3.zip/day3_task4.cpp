#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main(){
    int a;
    cout<<"Enter a number : ";
    cin>>a;
    if((a&1)==0)
        cout<<a<<" is an even number ";
    else   
        cout<<a<<" is an odd number ";    
}