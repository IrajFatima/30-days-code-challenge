#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main(){
    srand(time(0));
    int a=rand()% 90+10;
    int b=rand()% a;
    cout<<"Two random numbers are : "<<a<<" "<<b<<endl;
    ((a+b)%2==0)? cout<<"Their sum is even" : cout<<"Their sum is odd";
}