#include <iostream>
using namespace std;

void two_complement(char *arr, char *res, int n){
    for(int i=0;i<n;i++){
        if(arr[i]=='1') 
            res[i]='0';
        else if(arr[i]=='0') 
            res[i]='1';
    }
    bool carry=true;
    for(int i=n-1;i>=0;i--){
        if(res[i]=='0'&&carry){
            res[i]='1';
            carry=false;
        } 
        else if(res[i] =='1'&&carry)
            res[i]='0';
        if(!carry)
            break;
    }
    res[n-1]='\0';
}


int main(){
    char arr[10]="100101011";
    char res[11];
    two_complement(arr,res,10);
    cout<<res<<endl;
}