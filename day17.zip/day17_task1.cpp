#include <iostream>
using namespace std;

int count_zeros(unsigned int num){
    int count = 0;
    while(num != 0){
        if(num % 10 == 0)
            count++;  
        num/=10;
    }
    return count;    
}

int main(){
    unsigned int x;
    cin >> x;
    cout << count_zeros(x);
}