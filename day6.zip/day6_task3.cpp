#include <iostream>
using namespace std;
bool prime_number(int num){
    int i,prime=0;
    for(i=2;i<num;i++){
        if(num%i==0){
            return false;
        }
    }
    return true;

}
int sum_of_all_prime_numbers(int n){
    int i,sum=0;
    for(i=2;i<n;i++){
        if(prime_number(i)){
            sum+=i;
        }
    }
    return sum;
}

int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        cout<<sum_of_all_prime_numbers(n)<<endl;
    }

}