#include <iostream>
using namespace std;

void display_factors(int num){
    int i;
    cout<<"Factors of "<<num<<" are : "<<1<<" ";
    for(i=2;i<=num;i++){
        if(num%i==0)
            cout<<i<<" ";
    }
    cout<<endl;
}
int main(){
    int n;
    cout<<"number : ";
    cin>>n;
    display_factors(n);
}