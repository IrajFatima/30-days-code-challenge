#include <iostream>
#include <iomanip>
using namespace std;
void area_of_circle(int r){
    cout<<"Area of the circle : "<<fixed<<setprecision(1)<<(22/7.0)*r*r;
}
int main(){
    int r;
    cout<<"enter radius : ";
    cin>>r;
    area_of_circle(r);
}