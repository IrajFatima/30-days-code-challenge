#include <iostream>
using namespace std;


void one_complement(char *arr, char *res, int n){
    for(int i=0;i<n;i++){
        if(arr[i]=='1') 
            res[i]='0';
        else if(arr[i]=='0') 
            res[i]='1';
    }
    res[n-1]='\0';
}
int main(){
    char arr[10]="100101011";
    char res[10];
    one_complement(arr,res,10);
    cout<<res<<endl;
}