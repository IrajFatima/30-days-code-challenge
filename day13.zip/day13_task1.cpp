#include <iostream>
#include <string>
using namespace std;
int main(){
    string str;
    cout << "Input a string: ";
    getline(cin, str);
    cout<<"The string you entered is : "<<str;

}