#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int main(){
    string str;
    cout << "Input a string: ";
    getline(cin, str);
    for(auto &c : str){
        if(c==' ')
            c='*';
    }
    cout<<"new string : "<<str;
}