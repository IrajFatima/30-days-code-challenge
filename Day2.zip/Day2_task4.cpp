#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main(){
    int a,b;
    cout<<"Enter two numbers : ";
    cin>>a>>b;
    cout<<a<<"&"<<b<<"="<<(a&b)<<endl;
    cout<<a<<"|"<<b<<"="<<(a|b)<<endl;
    cout<<a<<"^"<<b<<"="<<(a^b)<<endl;
    cout<<a<<">>"<<2<<"="<<(a>>2)<<endl;
    cout<<b<<"<<"<<2<<"="<<(b<<2)<<endl;

}