#include <iostream>
#include <iomanip>
using namespace std;
int main(){
    int a,b;
    cout<<"First number : ";
    cin>>a;
    cout<<"Second number : ";
    cin>>b;
    (a==b)? cout<<1 : cout<<0;
} 