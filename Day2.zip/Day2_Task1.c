#include <stdio.h>
int main(){
    int l,w;
    printf("Enter length of rectangle = ");
    scanf("%d",&l);
    printf("Enter width of rectangle = ");
    scanf("%d",&w);
    printf("Area of rectangle = %d",l*w);
    return 0;
}