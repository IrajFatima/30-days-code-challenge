#include <iostream>
#include <iomanip>
using namespace std;

int main(){
    int arr[5];
    int sum=0;
    cout<<"Enter five numbers: ";
    for(int i=0;i<5;i++){
        cin>>arr[i];
        sum+=arr[i];
    }
    cout<<"Sum: "<<sum<<"\nAverage: "<<fixed<<setprecision(2)<<sum/5.0<<endl;
}