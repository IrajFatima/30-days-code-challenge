#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main(){
    int age;
    cout<<"Age: ";
    cin>>age;
    (age<18)? cout<<"Sorry, you are not eligible for vote" : cout<<"Bravo! You are eligible for vote.";
}