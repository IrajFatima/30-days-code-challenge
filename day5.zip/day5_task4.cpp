#include <iostream>
using namespace std;
#define num 5
int main(){
    int i,j;
    cout<<"(a)"<<endl<<endl;
    for(i=1;i<=num;i++){
        for(j=0;j<i;j++)
            cout<<"*";
        cout<<endl;    
    }
    cout<<endl<<endl;
    cout<<"(b)"<<endl<<endl;
    for(i=1;i<=num;i++){
        for(j=num;j>i-1;j--){
            cout<<"*";
        }
        cout<<endl;
    }
}