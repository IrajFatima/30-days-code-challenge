#include <iostream>
using namespace std;


bool palindrome(int num) {
    int o = num;
    int r = 0;
    while(num>0) {
        int digit=num%10;
        r=r*10+digit;
        num/=10;
    }

    return o == r;
}

int main(){
    int num;
    cout << "Enter a number: ";
    cin >> num;
    if (palindrome(num))
        cout <<"Palindrome number." <<endl;
    else
        cout<<"Not palindrome number." <<endl;
    return 0;
}
