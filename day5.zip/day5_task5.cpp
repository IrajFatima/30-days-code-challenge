#include <iostream>
using namespace std;
#include <string>

int main(){
    int range;
    cout<<"Enter range: ";
    cin>>range;
    for(int i=0;i<range;++i){
        for(int j=0;j<range-i-1;++j)
            cout<<" ";
        char ch='A';
        for(int j=0;j<=i;++j)
            cout<<ch++;
        ch-=2;
        for(int j=0;j<i;++j) 
            cout<<ch--;
        cout<<endl;
    }
    return 0;
}
