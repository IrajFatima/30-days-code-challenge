#include <iostream>
#include <cmath>
using namespace std;
bool armstrong_number(int num){
    int o=num;
    int digits=0;
    int sum=0;
    while(o!=0) {
        o/=10;
        ++digits;
    }
    o=num;
    while(o!=0) {
        int digit=o%10;
        sum+=pow(digit,digits);
        o/=10;
    }
    return sum == num;
}


int main(){
    int num;
    cout<<"Enter a number: ";
    cin>>num;
    if(armstrong_number(num))
        cout<<num<<" is an Armstrong number."<<endl;
    else 
        cout<<num<<" is not an Armstrong number."<<endl;
    return 0;
}
