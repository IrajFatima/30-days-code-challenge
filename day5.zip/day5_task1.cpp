#include <iostream>
using namespace std;

bool prime_number(int num){
    int i,prime=0;
    for(i=2;i<num;i++){
        if(num%i==0){
            return false;
        }
    }
    return true;

}

int main(){
    int num;
    cout<<"enter number : ";
    cin>>num;
    if(prime_number(num))
        cout<<num<<" is a prime number\n";
    else    
        cout<<num<<" is not a prime number\n";
}