#include <iostream>
using namespace std;

int main(){
    int arr[2][2];
    cout<<"Enter 2x2 matrix elements : ";        
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            cin>>arr[i][j];
    int det=(arr[0][0]*arr[1][1])-(arr[1][0]*arr[0][1]);
    cout<<"Determinant : "<<det;        
}