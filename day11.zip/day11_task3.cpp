#include <iostream>
using namespace std;

int second_max(int arr[], int size) {
    int max1=arr[0];
    int max2=arr[0]; 
    for(int i=1;i<size;++i)
        if (arr[i]>max1){
            max2=max1;
            max1=arr[i];
        }
        else if(arr[i]>max2&&arr[i]!=max1)
            max2=arr[i];
    return max2;
}



int main(){
    int size;
    cout<<"Enter array size : ";
    cin>>size;

    int arr[size];
    cout<<"Enter "<<size<<" elements: ";
    for(int i=0;i<size;++i)
        cin>>arr[i];
    cout<<"Second maximum element : "<<second_max(arr,size);
}